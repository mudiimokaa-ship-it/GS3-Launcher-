package com.gs3.launcher;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Reads the active media session (now playing), turn-by-turn notifications from
 * navigation apps, and incoming call notifications, and forwards them to the UI.
 */
public class MediaService extends NotificationListenerService
        implements MediaSessionManager.OnActiveSessionsChangedListener {

    static volatile MediaService inst;

    private static final Set<String> NAV_APPS = new HashSet<>(Arrays.asList(
            "com.google.android.apps.maps", "com.waze", "ru.yandex.yandexnavi",
            "com.sygic.aura", "com.here.app.maps", "net.osmand", "net.osmand.plus"));

    private final Handler ui = new Handler(Looper.getMainLooper());
    private MediaSessionManager msm;
    private MediaController ctl;
    private String lastArtKey = "";
    private String lastNavKey = "";
    private String navPkg = null;
    private String callKey = null;

    private final MediaController.Callback cb = new MediaController.Callback() {
        @Override public void onMetadataChanged(MediaMetadata metadata) { push(); }
        @Override public void onPlaybackStateChanged(PlaybackState state) { push(); }
        @Override public void onSessionDestroyed() { setController(null); pickSession(); }
    };

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        inst = this;
        try {
            msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            ComponentName cn = new ComponentName(this, MediaService.class);
            msm.addOnActiveSessionsChangedListener(this, cn, ui);
            onActiveSessionsChanged(msm.getActiveSessions(cn));
        } catch (Exception ignored) { }
        try {
            StatusBarNotification[] all = getActiveNotifications();
            if (all != null) for (StatusBarNotification s : all) handle(s);
        } catch (Exception ignored) { }
        MainActivity.send("onNotifAccess", "true");
    }

    @Override
    public void onListenerDisconnected() {
        try { if (msm != null) msm.removeOnActiveSessionsChangedListener(this); } catch (Exception ignored) { }
        setController(null);
        inst = null;
        super.onListenerDisconnected();
    }

    // ---------------- media sessions ----------------
    private void pickSession() {
        try {
            if (msm != null) onActiveSessionsChanged(msm.getActiveSessions(new ComponentName(this, MediaService.class)));
        } catch (Exception ignored) { }
    }

    @Override
    public void onActiveSessionsChanged(List<MediaController> list) {
        MediaController best = null;
        if (list != null) {
            for (MediaController c : list) {
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) { best = c; break; }
            }
            if (best == null && !list.isEmpty()) best = list.get(0);
        }
        if (best == null || ctl == null || !best.getSessionToken().equals(ctl.getSessionToken())) setController(best);
        push();
    }

    private void setController(MediaController c) {
        if (ctl != null) try { ctl.unregisterCallback(cb); } catch (Exception ignored) { }
        ctl = c;
        lastArtKey = "";
        if (ctl != null) try { ctl.registerCallback(cb, ui); } catch (Exception ignored) { }
    }

    void push() {
        try {
            JSONObject o = new JSONObject();
            if (ctl == null || ctl.getMetadata() == null) {
                o.put("has", false);
                MainActivity.send("onMedia", o.toString());
                return;
            }
            MediaMetadata m = ctl.getMetadata();
            PlaybackState st = ctl.getPlaybackState();
            String title = str(m.getString(MediaMetadata.METADATA_KEY_TITLE));
            if (title.isEmpty()) title = str(m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE));
            String artist = str(m.getString(MediaMetadata.METADATA_KEY_ARTIST));
            if (artist.isEmpty()) artist = str(m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST));
            if (artist.isEmpty()) artist = str(m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE));
            o.put("has", true);
            o.put("title", title);
            o.put("artist", artist);
            o.put("pkg", ctl.getPackageName());
            o.put("app", appLabel(ctl.getPackageName()));
            long dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION);
            o.put("dur", dur > 0 ? dur : 0);
            boolean playing = st != null && st.getState() == PlaybackState.STATE_PLAYING;
            o.put("playing", playing);
            long pos = 0;
            if (st != null) {
                pos = st.getPosition();
                if (playing && st.getLastPositionUpdateTime() > 0) {
                    pos += (long) ((SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime()) * st.getPlaybackSpeed());
                }
            }
            o.put("pos", Math.max(0, pos));
            String key = ctl.getPackageName() + "|" + title + "|" + artist;
            if (!key.equals(lastArtKey)) {
                Bitmap art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (art == null) art = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (art == null) art = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                o.put("art", art != null ? toDataUrl(art, 320, true) : "");
                lastArtKey = key;
            }
            MainActivity.send("onMedia", o.toString());
        } catch (Exception ignored) { }
    }

    /** Returns true if handled through the media session. */
    boolean control(String k) {
        if (ctl == null) return false;
        try {
            MediaController.TransportControls t = ctl.getTransportControls();
            if ("next".equals(k)) t.skipToNext();
            else if ("prev".equals(k)) t.skipToPrevious();
            else {
                PlaybackState st = ctl.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) t.pause(); else t.play();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    boolean seek(long ms) {
        if (ctl == null) return false;
        try { ctl.getTransportControls().seekTo(ms); return true; } catch (Exception e) { return false; }
    }

    // ---------------- notifications: navigation + calls ----------------
    @Override public void onNotificationPosted(StatusBarNotification sbn) { handle(sbn); }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        try {
            String pkg = sbn.getPackageName();
            if (pkg.equals(navPkg)) { navPkg = null; lastNavKey = ""; MainActivity.send("onNavEnd", "0"); }
            if (sbn.getKey().equals(callKey)) { callKey = null; MainActivity.send("onCallEnd", "0"); }
        } catch (Exception ignored) { }
    }

    private void handle(StatusBarNotification sbn) {
        try {
            Notification n = sbn.getNotification();
            if (n == null) return;
            Bundle e = n.extras;
            String pkg = sbn.getPackageName();
            String title = e != null ? str(e.getCharSequence(Notification.EXTRA_TITLE)) : "";
            String text = e != null ? str(e.getCharSequence(Notification.EXTRA_TEXT)) : "";
            String sub = e != null ? str(e.getCharSequence(Notification.EXTRA_SUB_TEXT)) : "";
            String big = e != null ? str(e.getCharSequence(Notification.EXTRA_BIG_TEXT)) : "";

            if (NAV_APPS.contains(pkg) && (n.flags & Notification.FLAG_ONGOING_EVENT) != 0 && !title.isEmpty()) {
                String key = title + "|" + text + "|" + sub;
                if (key.equals(lastNavKey)) return;
                lastNavKey = key;
                navPkg = pkg;
                JSONObject o = new JSONObject();
                o.put("app", appLabel(pkg));
                o.put("pkg", pkg);
                o.put("title", title);
                o.put("text", text.isEmpty() ? big : text);
                o.put("sub", sub);
                Bitmap icon = largeIcon(n);
                o.put("icon", icon != null ? toDataUrl(icon, 128, false) : "");
                MainActivity.send("onNav", o.toString());
                return;
            }

            if (Notification.CATEGORY_CALL.equals(n.category) && !title.isEmpty()) {
                callKey = sbn.getKey();
                JSONObject o = new JSONObject();
                o.put("name", title);
                o.put("text", text);
                o.put("app", appLabel(pkg));
                MainActivity.send("onCall", o.toString());
            }
        } catch (Exception ignored) { }
    }

    @SuppressWarnings("deprecation")
    private Bitmap largeIcon(Notification n) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                Icon ic = n.getLargeIcon();
                if (ic != null) {
                    Drawable d = ic.loadDrawable(this);
                    if (d != null) return drawableToBitmap(d, 128);
                }
            }
            Object o = n.extras != null ? n.extras.get(Notification.EXTRA_LARGE_ICON) : null;
            if (o instanceof Bitmap) return (Bitmap) o;
        } catch (Exception ignored) { }
        return null;
    }

    // ---------------- helpers ----------------
    static Bitmap drawableToBitmap(Drawable d, int size) {
        if (d instanceof BitmapDrawable && ((BitmapDrawable) d).getBitmap() != null) return ((BitmapDrawable) d).getBitmap();
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        return b;
    }

    static String toDataUrl(Bitmap src, int max, boolean jpeg) {
        Bitmap b = src;
        int w = src.getWidth(), h = src.getHeight();
        if (w > max || h > max) {
            float s = Math.min((float) max / w, (float) max / h);
            b = Bitmap.createScaledBitmap(src, Math.max(1, (int) (w * s)), Math.max(1, (int) (h * s)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(jpeg ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG, jpeg ? 85 : 100, out);
        return (jpeg ? "data:image/jpeg;base64," : "data:image/png;base64,") + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private String appLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return String.valueOf(pm.getApplicationLabel(ai));
        } catch (Exception e) {
            return pkg;
        }
    }

    private static String str(CharSequence c) { return c == null ? "" : c.toString(); }
}
