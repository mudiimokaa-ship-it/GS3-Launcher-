package com.gs3.launcher;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Minimal ELM327 client. Works with Bluetooth Classic (SPP) adapters and BLE adapters
 * (Vgate iCar Pro BLE / 2S, Veepeak BLE, vLinker ...). Results go to the UI as JSON.
 */
@SuppressLint("MissingPermission")
public class Obd {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final Context ctx;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean run = false;
    private volatile boolean wantDtc = false, wantClear = false;
    private Thread th;
    private String addr;

    // classic
    private BluetoothSocket sock;
    private InputStream in;
    private OutputStream out;
    // ble
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic wch;
    private final StringBuilder bleBuf = new StringBuilder();
    private final Object lock = new Object();
    private CountDownLatch servicesReady;
    private volatile boolean bleConnected = false;
    private boolean ble = false;
    private boolean can = true;

    Obd(Context c) { ctx = c.getApplicationContext(); }

    boolean isRunning() { return run; }

    // ---------------- device discovery ----------------
    String bondedDevices() {
        JSONArray arr = new JSONArray();
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null) return "[]";
            for (BluetoothDevice d : ad.getBondedDevices()) {
                JSONObject o = new JSONObject();
                o.put("name", d.getName() == null ? d.getAddress() : d.getName());
                o.put("addr", d.getAddress());
                o.put("ble", d.getType() == BluetoothDevice.DEVICE_TYPE_LE);
                arr.put(o);
            }
        } catch (Exception ignored) { }
        return arr.toString();
    }

    private ScanCallback scanCb;

    void scanBle() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null || !ad.isEnabled()) { state("error", "البلوتوث مقفول"); return; }
            final BluetoothLeScanner sc = ad.getBluetoothLeScanner();
            if (sc == null) return;
            final HashMap<String, Boolean> seen = new HashMap<>();
            scanCb = new ScanCallback() {
                @Override public void onScanResult(int callbackType, ScanResult r) {
                    try {
                        BluetoothDevice d = r.getDevice();
                        String name = d.getName();
                        if (name == null || seen.containsKey(d.getAddress())) return;
                        seen.put(d.getAddress(), true);
                        JSONObject o = new JSONObject();
                        o.put("name", name);
                        o.put("addr", d.getAddress());
                        o.put("ble", true);
                        MainActivity.send("onObdFound", o.toString());
                    } catch (Exception ignored) { }
                }
            };
            sc.startScan(scanCb);
            ui.postDelayed(new Runnable() { @Override public void run() {
                try { sc.stopScan(scanCb); } catch (Exception ignored) { }
                MainActivity.send("onObdScanDone", "0");
            }}, 8000);
        } catch (Exception e) {
            state("error", "مقدرتش أدوّر على أجهزة");
        }
    }

    // ---------------- lifecycle ----------------
    void connect(String address) {
        stop();
        addr = address;
        run = true;
        th = new Thread(new Runnable() { @Override public void run() { loop(); } }, "obd");
        th.start();
    }

    void stop() {
        run = false;
        if (th != null) th.interrupt();
        closeAll();
        state("off", "");
    }

    void readDtc() { wantDtc = true; }
    void clearDtc() { wantClear = true; }

    private void loop() {
        while (run) {
            try {
                state("connecting", "");
                open();
                init();
                state("connected", "");
                int cycle = 0;
                JSONObject slow = new JSONObject();
                while (run) {
                    JSONObject o = new JSONObject();
                    putNum(o, "rpm", pidVal("0C"));
                    putNum(o, "speed", pidVal("0D"));
                    if (cycle % 6 == 0) {
                        slow = new JSONObject();
                        putNum(slow, "coolant", pidVal("05"));
                        putNum(slow, "load", pidVal("04"));
                        putNum(slow, "throttle", pidVal("11"));
                        putNum(slow, "fuel", pidVal("2F"));
                        putNum(slow, "intake", pidVal("0F"));
                        String v = clean(cmd("ATRV", 1500)).replace("V", "");
                        try { slow.put("volt", Double.parseDouble(v)); } catch (Exception ignored) { }
                    }
                    java.util.Iterator<String> it = slow.keys();
                    while (it.hasNext()) { String k = it.next(); o.put(k, slow.get(k)); }
                    MainActivity.send("onObd", o.toString());
                    if (wantDtc) { wantDtc = false; sendDtc(); }
                    if (wantClear) { wantClear = false; cmd("04", 5000); sendDtc(); }
                    cycle++;
                    Thread.sleep(150);
                }
            } catch (InterruptedException ie) {
                break;
            } catch (Exception e) {
                state("error", "انقطع الاتصال بالـ OBD، بحاول تاني…");
            }
            closeAll();
            if (run) try { Thread.sleep(5000); } catch (InterruptedException ie) { break; }
        }
    }

    private void open() throws Exception {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) throw new IOException("bt off");
        BluetoothDevice dev = ad.getRemoteDevice(addr);
        int type = dev.getType();
        if (type == BluetoothDevice.DEVICE_TYPE_LE) { openBle(dev); return; }
        try { ad.cancelDiscovery(); } catch (Exception ignored) { }
        try {
            sock = dev.createRfcommSocketToServiceRecord(SPP);
            sock.connect();
        } catch (IOException e) {
            try { if (sock != null) sock.close(); } catch (Exception ignored) { }
            try {
                sock = (BluetoothSocket) dev.getClass().getMethod("createRfcommSocket", int.class).invoke(dev, 1);
                sock.connect();
            } catch (Exception e2) {
                if (type == BluetoothDevice.DEVICE_TYPE_DUAL || type == BluetoothDevice.DEVICE_TYPE_UNKNOWN) { openBle(dev); return; }
                throw new IOException("connect failed");
            }
        }
        in = sock.getInputStream();
        out = sock.getOutputStream();
        ble = false;
    }

    private void openBle(BluetoothDevice dev) throws Exception {
        servicesReady = new CountDownLatch(1);
        BluetoothGattCallback cb = new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
                if (newState == BluetoothProfile.STATE_CONNECTED) { bleConnected = true; g.discoverServices(); }
                else if (newState == BluetoothProfile.STATE_DISCONNECTED) { bleConnected = false; synchronized (lock) { lock.notifyAll(); } }
            }
            @Override public void onServicesDiscovered(BluetoothGatt g, int status) { servicesReady.countDown(); }
            @SuppressWarnings("deprecation")
            @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
                byte[] v = c.getValue();
                if (v == null) return;
                synchronized (lock) { bleBuf.append(new String(v, StandardCharsets.US_ASCII)); lock.notifyAll(); }
            }
        };
        if (Build.VERSION.SDK_INT >= 23) gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE);
        else gatt = dev.connectGatt(ctx, false, cb);
        if (!servicesReady.await(15, TimeUnit.SECONDS)) throw new IOException("ble timeout");

        BluetoothGattCharacteristic notify = null, write = null;
        for (BluetoothGattService s : gatt.getServices()) {
            BluetoothGattCharacteristic n = null, w = null;
            for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                int p = c.getProperties();
                if (n == null && (p & (BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0) n = c;
                if (w == null && (p & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) w = c;
            }
            String su = s.getUuid().toString().toLowerCase(Locale.US);
            if (su.startsWith("00001800") || su.startsWith("00001801") || su.startsWith("0000180a")) continue; // generic services
            if (n != null && w != null) { notify = n; write = w; break; }
            if (notify == null && n != null) notify = n;
            if (write == null && w != null) write = w;
        }
        if (notify == null || write == null) throw new IOException("no ble uart");
        gatt.setCharacteristicNotification(notify, true);
        BluetoothGattDescriptor d = notify.getDescriptor(CCCD);
        if (d != null) {
            setDescriptor(d, (notify.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
                    ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
            Thread.sleep(300);
        }
        wch = write;
        ble = true;
    }

    @SuppressWarnings("deprecation")
    private void setDescriptor(BluetoothGattDescriptor d, byte[] v) {
        d.setValue(v);
        gatt.writeDescriptor(d);
    }

    @SuppressWarnings("deprecation")
    private void bleWrite(byte[] data) {
        wch.setValue(data);
        wch.setWriteType((wch.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        gatt.writeCharacteristic(wch);
    }

    private void closeAll() {
        try { if (sock != null) sock.close(); } catch (Exception ignored) { }
        sock = null; in = null; out = null;
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) { }
        gatt = null; wch = null; bleConnected = false;
    }

    // ---------------- ELM327 protocol ----------------
    private void init() throws Exception {
        cmd("ATZ", 3000);
        Thread.sleep(300);
        cmd("ATE0", 1500);
        cmd("ATL0", 1500);
        cmd("ATS0", 1500);
        cmd("ATH0", 1500);
        cmd("ATSP0", 1500);
        String r = clean(cmd("0100", 10000));
        if (!r.contains("4100")) {
            if (r.contains("UNABLETOCONNECT") || r.contains("NODATA")) throw new IOException("ecu");
        }
        String dp = clean(cmd("ATDPN", 1500));
        char p = dp.isEmpty() ? '6' : dp.charAt(dp.length() - 1);
        can = p >= '6' && p <= '9' || p == 'A' || p == 'B' || p == 'C';
    }

    private String cmd(String c, long timeoutMs) throws Exception {
        byte[] data = (c + "\r").getBytes(StandardCharsets.US_ASCII);
        long end = System.currentTimeMillis() + timeoutMs;
        if (ble) {
            if (gatt == null || wch == null || !bleConnected) throw new IOException("ble closed");
            synchronized (lock) { bleBuf.setLength(0); }
            bleWrite(data);
            synchronized (lock) {
                while (bleBuf.indexOf(">") < 0) {
                    long left = end - System.currentTimeMillis();
                    if (left <= 0 || !bleConnected) break;
                    lock.wait(left);
                }
                String r = bleBuf.toString();
                bleBuf.setLength(0);
                if (!bleConnected) throw new IOException("ble closed");
                return r;
            }
        }
        if (in == null || out == null) throw new IOException("closed");
        while (in.available() > 0) in.read();
        out.write(data);
        out.flush();
        StringBuilder sb = new StringBuilder();
        while (System.currentTimeMillis() < end) {
            if (in.available() > 0) {
                int b = in.read();
                if (b < 0) throw new IOException("eof");
                if (b == '>') break;
                sb.append((char) b);
            } else {
                Thread.sleep(5);
            }
        }
        return sb.toString();
    }

    private static String clean(String r) {
        return r.toUpperCase(Locale.US).replace("SEARCHING...", "").replace(">", "")
                .replace(" ", "").replace("\r", "").replace("\n", "").replace("\t", "");
    }

    private int[] pid(String p) throws Exception {
        String r = clean(cmd("01" + p, 1500));
        int i = r.indexOf("41" + p);
        if (i < 0) return null;
        String hex = r.substring(i + 4);
        int n = Math.min(hex.length() / 2, 4);
        int[] b = new int[n];
        for (int k = 0; k < n; k++) {
            try { b[k] = Integer.parseInt(hex.substring(k * 2, k * 2 + 2), 16); } catch (Exception e) { return null; }
        }
        return n > 0 ? b : null;
    }

    private Double pidVal(String p) throws Exception {
        int[] b = pid(p);
        if (b == null) return null;
        switch (p) {
            case "0C": return b.length >= 2 ? ((b[0] * 256.0) + b[1]) / 4.0 : null;
            case "0D": return (double) b[0];
            case "05": case "0F": return b[0] - 40.0;
            case "04": case "11": case "2F": return b[0] * 100.0 / 255.0;
            default: return null;
        }
    }

    private static void putNum(JSONObject o, String k, Double v) {
        if (v == null) return;
        try { o.put(k, Math.round(v * 10) / 10.0); } catch (Exception ignored) { }
    }

    private void sendDtc() {
        try {
            String raw = cmd("03", 5000).toUpperCase(Locale.US);
            StringBuilder data = new StringBuilder();
            for (String line : raw.split("[\\r\\n]+")) {
                String l = line.replace(" ", "").replace(">", "").replace("SEARCHING...", "").trim();
                if (l.isEmpty() || l.equals("NODATA")) continue;
                int colon = l.indexOf(':');
                if (colon >= 0 && colon <= 2) l = l.substring(colon + 1); // multi-frame "0:", "1:" prefixes
                else if (l.length() == 3) continue;                       // multi-frame byte count header
                data.append(l);
            }
            String d = data.toString();
            JSONArray codes = new JSONArray();
            int i = d.indexOf("43");
            if (i >= 0) {
                d = d.substring(i + 2);
                if (can && d.length() >= 2) d = d.substring(2); // CAN: number-of-codes byte
                for (int k = 0; k + 4 <= d.length(); k += 4) {
                    String c = d.substring(k, k + 4);
                    if (c.equals("0000")) continue;
                    int first = Integer.parseInt(c.substring(0, 1), 16);
                    String code = "PCBU".charAt(first >> 2) + Integer.toString(first & 3) + c.substring(1);
                    codes.put(code);
                }
            }
            MainActivity.send("onObdDtc", codes.toString());
        } catch (Exception e) {
            MainActivity.send("onObdDtc", "[]");
        }
    }

    private void state(String s, String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("state", s);
            o.put("msg", msg);
            MainActivity.send("onObdState", o.toString());
        } catch (Exception ignored) { }
    }
}
