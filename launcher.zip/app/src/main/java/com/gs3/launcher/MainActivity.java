package com.gs3.launcher;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {

    static volatile MainActivity inst;

    private WebView web;
    private LocationManager lm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final HashMap<String, String> iconCache = new HashMap<>();
    private volatile boolean pageReady = false;
    private volatile boolean loadingApps = false;
    private Obd obd;
    private Updater updater;
    private android.speech.tts.TextToSpeech tts;
    private boolean ttsReady = false;
    private View bubble;
    private String pendingObdAction = null;
    private volatile String pendingShare = null;

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShare(intent);
    }

    /** A location shared to the launcher (geo: link, Google Maps link, or text). */
    void handleShare(Intent i) {
        if (i == null) return;
        String a = i.getAction();
        if (a == null || Intent.ACTION_MAIN.equals(a)) return;
        String t = null;
        if (Intent.ACTION_SEND.equals(a)) {
            CharSequence cs = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (cs != null) t = cs.toString();
            String sub = i.getStringExtra(Intent.EXTRA_SUBJECT);
            if (sub != null && t != null) t = sub + "\n" + t;
        } else if (Intent.ACTION_VIEW.equals(a)) {
            t = i.getDataString();
        }
        if (t == null || t.trim().isEmpty()) return;
        resolveAndSend(t);
    }

    void resolveAndSend(final String text) {
        new Thread(new Runnable() {
            @Override public void run() {
                String out = text;
                try {
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("https?://[^\\s]+").matcher(text);
                    if (m.find()) {
                        String u = m.group(), last = u;
                        for (int k = 0; k < 6 && u != null; k++) {
                            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
                            c.setInstanceFollowRedirects(false);
                            c.setConnectTimeout(8000);
                            c.setReadTimeout(8000);
                            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
                            int code = c.getResponseCode();
                            String loc = c.getHeaderField("Location");
                            c.disconnect();
                            if (code >= 300 && code < 400 && loc != null) {
                                u = new java.net.URL(new java.net.URL(u), loc).toString();
                                last = u;
                            } else u = null;
                        }
                        if (!last.equals(m.group())) out = text + "\n" + java.net.URLDecoder.decode(last, "UTF-8");
                    }
                } catch (Exception ignored) { }
                final String fin = out;
                if (pageReady) send("onShared", JSONObject.quote(fin));
                else pendingShare = fin;
            }
        }).start();
    }

    /** Calls window[fn](arg) in the page. arg must be a valid JS expression (JSON, number, boolean). */
    static void send(String fn, String arg) {
        MainActivity a = inst;
        if (a != null) a.js("window." + fn + "&&" + fn + "(" + arg + ")");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inst = this;
        obd = new Obd(this);
        updater = new Updater(this);
        try {
            tts = new android.speech.tts.TextToSpeech(this, new android.speech.tts.TextToSpeech.OnInitListener() {
                @Override public void onInit(int status) {
                    if (status != android.speech.tts.TextToSpeech.SUCCESS) return;
                    int r = tts.setLanguage(new Locale("ar", "EG"));
                    if (r < 0) r = tts.setLanguage(new Locale("ar"));
                    ttsReady = r >= 0;
                }
            });
        } catch (Exception ignored) { }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

        web = new WebView(this);
        web.setBackgroundColor(0xFF05080F);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                startGps();
                send("onNotifAccess", String.valueOf(hasNotifAccess()));
                if (MediaService.inst != null) MediaService.inst.push();
                final String ps = pendingShare;
                if (ps != null) {
                    pendingShare = null;
                    ui.postDelayed(new Runnable() { @Override public void run() { send("onShared", JSONObject.quote(ps)); } }, 2500);
                }
            }
        });
        setContentView(web);
        hideSystemUi();
        web.loadUrl("file:///android_asset/index.html");
        askLocationPermission();
        handleShare(getIntent());
    }

    void js(final String code) {
        if (!pageReady) return;
        ui.post(new Runnable() {
            @Override public void run() { if (web != null) web.evaluateJavascript(code, null); }
        });
    }

    // ---------------- permissions ----------------
    private boolean granted(String p) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasLocationPermission() { return granted(Manifest.permission.ACCESS_FINE_LOCATION); }

    private void askLocationPermission() {
        if (!hasLocationPermission() && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    private boolean ensureBtPermission(String action) {
        if (Build.VERSION.SDK_INT >= 31) {
            List<String> need = new ArrayList<>();
            if (!granted("android.permission.BLUETOOTH_CONNECT")) need.add("android.permission.BLUETOOTH_CONNECT");
            if (!granted("android.permission.BLUETOOTH_SCAN")) need.add("android.permission.BLUETOOTH_SCAN");
            if (!need.isEmpty()) {
                pendingObdAction = action;
                requestPermissions(need.toArray(new String[0]), 2);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) startGps();
        if (requestCode == 2 && pendingObdAction != null) {
            String a = pendingObdAction;
            pendingObdAction = null;
            send("onObdPermission", JSONObject.quote(a));
        }
    }

    private boolean hasNotifAccess() {
        try {
            String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            return flat != null && flat.contains(new ComponentName(this, MediaService.class).flattenToString());
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------- GPS ----------------
    private void startGps() {
        if (!pageReady) return;
        if (!hasLocationPermission()) { send("onNoGps", "0"); return; }
        try {
            if (lm == null) lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            lm.removeUpdates(this);
            boolean any = false;
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this);
                any = true;
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 50, this);
                any = true;
            }
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) sendLocation(last, false);
            if (!any) send("onNoGps", "0");
        } catch (SecurityException | IllegalArgumentException e) {
            send("onNoGps", "0");
        }
    }

    private void sendLocation(Location l, boolean live) {
        boolean hasSpeed = live && l.hasSpeed();
        String code = String.format(Locale.US,
                "window.onNativeLocation&&onNativeLocation(%.6f,%.6f,%.2f,%b,%.1f,%.1f,%b)",
                l.getLatitude(), l.getLongitude(), hasSpeed ? l.getSpeed() : 0f, hasSpeed,
                l.hasAccuracy() ? l.getAccuracy() : 99f,
                l.hasBearing() ? l.getBearing() : 0f, live && l.hasBearing());
        js(code);
    }

    @Override public void onLocationChanged(Location location) { sendLocation(location, true); }
    @Override public void onProviderEnabled(String provider) { startGps(); }
    @Override public void onProviderDisabled(String provider) { }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    // ---------------- lifecycle ----------------
    @Override
    protected void onResume() {
        super.onResume();
        inst = this;
        hideSystemUi();
        web.onResume();
        hideBubble();
        send("onResumeApp", "0");
        send("onNotifAccess", String.valueOf(hasNotifAccess()));
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Deliberately not calling web.onPause(): radio, GPS, trips and OBD keep running
        // while navigation or another app is in front.
        web.resumeTimers();
        send("onPauseApp", "0");
    }

    @Override
    protected void onDestroy() {
        if (lm != null) try { lm.removeUpdates(this); } catch (Exception ignored) { }
        if (obd != null) obd.stop();
        if (tts != null) try { tts.shutdown(); } catch (Exception ignored) { }
        hideBubble();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        send("onBack", "0");
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    // ---------------- voice commands + backup files ----------------
    private static final int REQ_VOICE = 31, REQ_BACKUP_SAVE = 32, REQ_BACKUP_OPEN = 33;
    private String pendingBackup = null;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VOICE) {
            String text = "";
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) text = r.get(0);
            }
            send("onVoice", JSONObject.quote(text));
        } else if (requestCode == REQ_BACKUP_SAVE) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackup != null) {
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(data.getData());
                    os.write(pendingBackup.getBytes("UTF-8"));
                    os.close();
                    ok = true;
                } catch (Exception ignored) { }
            }
            pendingBackup = null;
            send("onBackupSaved", String.valueOf(ok));
        } else if (requestCode == REQ_BACKUP_OPEN) {
            String json = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    java.io.InputStream is = getContentResolver().openInputStream(data.getData());
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                    is.close();
                    json = bo.toString("UTF-8");
                } catch (Exception ignored) { }
            }
            send("onBackupLoaded", json == null ? "null" : JSONObject.quote(json));
        }
    }

    // ---------------- floating "back to launcher" button over Waze / Maps ----------------
    private boolean canOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }

    @SuppressWarnings("deprecation")
    private void showBubble() {
        if (bubble != null || !canOverlay()) return;
        try {
            final WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            float d = getResources().getDisplayMetrics().density;
            int size = (int) (64 * d);
            android.widget.TextView b = new android.widget.TextView(this);
            b.setText("⌂");
            b.setTextSize(30);
            b.setTextColor(0xFFFFFFFF);
            b.setGravity(android.view.Gravity.CENTER);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            bg.setColors(new int[]{0xFF3D8BFF, 0xFF5CE1FF});
            bg.setStroke((int) (2 * d), 0xFFFFFFFF);
            b.setBackground(bg);
            b.setElevation(8 * d);
            final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
                    Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    android.graphics.PixelFormat.TRANSLUCENT);
            lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            lp.x = (int) (16 * d);
            lp.y = (int) (getResources().getDisplayMetrics().heightPixels / 2 - size / 2);
            final float[] down = new float[4];
            final boolean[] moved = new boolean[1];
            b.setOnTouchListener(new View.OnTouchListener() {
                @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                    switch (e.getAction()) {
                        case android.view.MotionEvent.ACTION_DOWN:
                            down[0] = e.getRawX(); down[1] = e.getRawY(); down[2] = lp.x; down[3] = lp.y; moved[0] = false; return true;
                        case android.view.MotionEvent.ACTION_MOVE:
                            float dx = e.getRawX() - down[0], dy = e.getRawY() - down[1];
                            if (Math.abs(dx) + Math.abs(dy) > 12) moved[0] = true;
                            lp.x = (int) (down[2] + dx); lp.y = (int) (down[3] + dy);
                            try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
                            return true;
                        case android.view.MotionEvent.ACTION_UP:
                            if (!moved[0]) bringToFront();
                            return true;
                    }
                    return false;
                }
            });
            wm.addView(b, lp);
            bubble = b;
        } catch (Exception e) {
            bubble = null;
        }
    }

    private void hideBubble() {
        if (bubble == null) return;
        try { ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(bubble); } catch (Exception ignored) { }
        bubble = null;
    }

    private void bringToFront() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try { startActivity(i); } catch (Exception ignored) { }
        hideBubble();
    }

    // ---------------- apps ----------------
    private String iconToDataUrl(String pkg, Drawable d) {
        String cached = iconCache.get(pkg);
        if (cached != null) return cached;
        int size = 144;
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        b.recycle();
        String url = "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        iconCache.put(pkg, url);
        return url;
    }

    private void loadApps() {
        if (loadingApps) return;
        loadingApps = true;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    PackageManager pm = getPackageManager();
                    Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
                    JSONArray arr = new JSONArray();
                    for (ResolveInfo r : list) {
                        String pkg = r.activityInfo.packageName;
                        if (pkg.equals(getPackageName())) continue;
                        JSONObject o = new JSONObject();
                        o.put("pkg", pkg);
                        o.put("label", String.valueOf(r.loadLabel(pm)));
                        try { o.put("icon", iconToDataUrl(pkg, r.loadIcon(pm))); } catch (Exception ignored) { }
                        arr.put(o);
                    }
                    send("onApps", arr.toString());
                } catch (Exception ignored) {
                } finally {
                    loadingApps = false;
                }
            }
        }).start();
    }

    private void sendMediaKey(int code) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        long t = SystemClock.uptimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0));
    }

    private boolean startSafe(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void launchPkg(String pkg) {
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null || !startSafe(li)) send("onLaunchFail", "0");
    }

    // ---------------- JS bridge ----------------
    private class Bridge {
        @JavascriptInterface public void requestApps() { loadApps(); }

        @JavascriptInterface public void launchApp(final String pkg) {
            ui.post(new Runnable() { @Override public void run() { launchPkg(pkg); }});
        }

        @JavascriptInterface public void navigate(final double lat, final double lon, final String app) {
            ui.post(new Runnable() { @Override public void run() {
                String ll = String.format(Locale.US, "%.6f,%.6f", lat, lon);
                Intent i;
                if ("com.waze".equals(app)) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?ll=" + ll + "&navigate=yes"));
                    i.setPackage("com.waze");
                } else if ("com.google.android.apps.maps".equals(app)) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + ll));
                    i.setPackage("com.google.android.apps.maps");
                } else {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + ll + "?q=" + ll));
                }
                if (!startSafe(i)) {
                    Intent g = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + ll + "?q=" + ll));
                    if (!startSafe(g)) send("onLaunchFail", "0");
                }
            }});
        }

        @JavascriptInterface public void mediaKey(String k) {
            MediaService ms = MediaService.inst;
            if (ms != null && ms.control(k)) return;
            int code = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
            if ("next".equals(k)) code = KeyEvent.KEYCODE_MEDIA_NEXT;
            else if ("prev".equals(k)) code = KeyEvent.KEYCODE_MEDIA_PREVIOUS;
            sendMediaKey(code);
        }

        @JavascriptInterface public void mediaSeek(double ms) {
            MediaService m = MediaService.inst;
            if (m != null) m.seek((long) ms);
        }

        @JavascriptInterface public boolean notifAccess() { return hasNotifAccess(); }

        @JavascriptInterface public void openNotifAccess() {
            ui.post(new Runnable() { @Override public void run() {
                if (!startSafe(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")))
                    startSafe(new Intent(Settings.ACTION_SETTINGS));
            }});
        }

        @JavascriptInterface public void openSettings() {
            ui.post(new Runnable() { @Override public void run() { startSafe(new Intent(Settings.ACTION_SETTINGS)); }});
        }

        @JavascriptInterface public void openBtSettings() {
            ui.post(new Runnable() { @Override public void run() { startSafe(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); }});
        }

        @JavascriptInterface public void chooseHome() {
            ui.post(new Runnable() { @Override public void run() {
                Intent i = new Intent(Settings.ACTION_HOME_SETTINGS);
                if (i.resolveActivity(getPackageManager()) == null) {
                    i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
                }
                startSafe(i);
            }});
        }

        // ---- voice + backup ----
        @JavascriptInterface public void listen() {
            ui.post(new Runnable() { @Override public void run() {
                Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "ar-EG");
                i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "قول أمرك…");
                try { startActivityForResult(i, REQ_VOICE); } catch (Exception e) { send("onVoice", "null"); }
            }});
        }
        @JavascriptInterface public void backupSave(final String json) {
            ui.post(new Runnable() { @Override public void run() {
                pendingBackup = json;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "GS3-Launcher-backup.json");
                try { startActivityForResult(i, REQ_BACKUP_SAVE); } catch (Exception e) { send("onBackupSaved", "false"); }
            }});
        }
        @JavascriptInterface public void backupOpen() {
            ui.post(new Runnable() { @Override public void run() {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try { startActivityForResult(i, REQ_BACKUP_OPEN); } catch (Exception e) { send("onBackupLoaded", "null"); }
            }});
        }

        // ---- floating back button ----
        @JavascriptInterface public boolean canOverlay() { return MainActivity.this.canOverlay(); }
        @JavascriptInterface public void openOverlayPermission() {
            ui.post(new Runnable() { @Override public void run() {
                if (!startSafe(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName()))))
                    startSafe(new Intent(Settings.ACTION_SETTINGS));
            }});
        }
        @JavascriptInterface public void showBubbleSoon() {
            ui.postDelayed(new Runnable() { @Override public void run() { showBubble(); }}, 1500);
        }

        // ---- voice guidance ----
        @JavascriptInterface public boolean canSpeak() { return ttsReady; }
        @SuppressWarnings("deprecation")
        @JavascriptInterface public void speak(String text) {
            if (tts == null || !ttsReady || text == null) return;
            try { tts.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null); } catch (Exception ignored) { }
        }

        // ---- version / update ----
        @JavascriptInterface public int appVersion() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode; } catch (Exception e) { return 0; }
        }
        @JavascriptInterface public boolean canInstall() { return updater.canInstall(); }
        @JavascriptInterface public void openInstallPermission() {
            ui.post(new Runnable() { @Override public void run() { startSafe(updater.installPermissionIntent()); }});
        }
        @JavascriptInterface public void downloadUpdate(String url) {
            if (url != null && url.startsWith("https://")) updater.download(url);
        }

        // ---- quick controls ----
        @JavascriptInterface public String volume(int delta) {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (delta != 0) am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    delta > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            return am.getStreamVolume(AudioManager.STREAM_MUSIC) + "," + am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        }
        @JavascriptInterface public void setBrightness(final float v) {
            ui.post(new Runnable() { @Override public void run() {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = v < 0 ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : Math.max(0.05f, Math.min(1f, v));
                getWindow().setAttributes(lp);
            }});
        }
        @SuppressWarnings("deprecation")
        @JavascriptInterface public String status() {
            boolean wifi = false, net = false, bt = false;
            try {
                android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
                net = ni != null && ni.isConnected();
                wifi = net && ni.getType() == android.net.ConnectivityManager.TYPE_WIFI;
            } catch (Exception ignored) { }
            try {
                android.bluetooth.BluetoothAdapter ad = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
                bt = ad != null && ad.isEnabled();
            } catch (Exception ignored) { }
            return "{\"wifi\":" + wifi + ",\"net\":" + net + ",\"bt\":" + bt + "}";
        }
        @JavascriptInterface public void openWifiSettings() {
            ui.post(new Runnable() { @Override public void run() { startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS)); }});
        }

        // ---- OBD ----
        @JavascriptInterface public String obdBonded() {
            if (!ensureBtPermission("list")) return "null";
            return obd.bondedDevices();
        }
        @JavascriptInterface public void obdScan() { if (ensureBtPermission("scan")) obd.scanBle(); }
        @JavascriptInterface public void obdConnect(String addr) { if (ensureBtPermission("connect")) obd.connect(addr); }
        @JavascriptInterface public void obdDisconnect() { obd.stop(); }
        @JavascriptInterface public void obdReadDtc() { obd.readDtc(); }
        @JavascriptInterface public void obdClearDtc() { obd.clearDtc(); }

        @JavascriptInterface public boolean copyText(String t) {
            try {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("GS3", t));
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public void resolveLink(String t) { if (t != null) resolveAndSend(t); }

        @JavascriptInterface public void beep() {
            try {
                final ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90);
                tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 400);
                ui.postDelayed(new Runnable() { @Override public void run() { tg.release(); }}, 800);
            } catch (Exception ignored) { }
        }

        @SuppressWarnings("deprecation")
        @JavascriptInterface public void vibrate() {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(40);
            } catch (Exception ignored) { }
        }
    }
}
