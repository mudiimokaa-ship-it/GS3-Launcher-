package com.gs3.launcher;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import java.io.File;

/** Downloads a new APK from GitHub Releases and opens the system installer. */
class Updater {
    private final Context ctx;
    private long downloadId = -1;
    private BroadcastReceiver receiver;

    Updater(Context c) { ctx = c.getApplicationContext(); }

    /** On Android 8+ the user must allow this app to install apps once. */
    boolean canInstall() {
        return Build.VERSION.SDK_INT < 26 || ctx.getPackageManager().canRequestPackageInstalls();
    }

    Intent installPermissionIntent() {
        return new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.getPackageName()));
    }

    void download(String url) {
        try {
            File old = new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "gs3-update.apk");
            if (old.exists()) old.delete();
            DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle("GS3 Launcher");
            r.setDescription("تحديث جديد");
            r.setMimeType("application/vnd.android.package-archive");
            r.setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, "gs3-update.apk");
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
            downloadId = dm.enqueue(r);
            listen();
            MainActivity.send("onUpdateState", "\"downloading\"");
        } catch (Exception e) {
            MainActivity.send("onUpdateState", "\"error\"");
        }
    }

    private void listen() {
        if (receiver != null) return;
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                long id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (id != downloadId) return;
                install();
            }
        };
        IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, f, 2 /* RECEIVER_EXPORTED */);
        else ctx.registerReceiver(receiver, f);
    }

    private void install() {
        try {
            DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
            Uri uri = dm.getUriForDownloadedFile(downloadId);
            if (uri == null) { MainActivity.send("onUpdateState", "\"error\""); return; }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            MainActivity.send("onUpdateState", "\"installing\"");
        } catch (Exception e) {
            MainActivity.send("onUpdateState", "\"error\"");
        }
    }
}
